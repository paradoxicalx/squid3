<?xml version="1.0" encoding="UTF-8"?>
<settings>
<client ip="103.195.19.203" lat="-7.6806" lon="110.2930" isp="Wavenet Media Service" isprating="2.7" rating="0" ispdlavg="3138" ispulavg="1394" loggedin="0" />
<server-config threadcount="4" ignoreids="683,1525,1758,1762,1815,1816,1834,1839,1840,1850,1854,1859,1860,1861,1871,1873,1875,1880,1902,1913,3280,3383,3448,3695,3696,3697,3698,3699,3725,3726,3727,3728,3729,3730,3731,3733,3788,3913,4140,4533,4787,5023,5024,5025,5026,5027,5028,5029,5030,5031,5032,5033,5085,5086,5087,5107,5108,5109,5111,5112,5113,5114,5115,5116,5117,5118,5517,6130,6285,6397,6398,6412,7326,7334,7529,8591,9123,9245,9816,10221,10226,10556,10557,10558,10559,10560,10561,10563,10565,10566,10567,10901,10923,949,5249" notonmap="4179,3378,5237,5718,4231,4781,6051,4247,9905,10299,10309,4810,6931,9644,10453,11076,3606,8809,9984,6891,7594,10870,5834,8455,7322,8670,8009,11077,5681,6866,4908,4745,6616,1930,4503,6563,6985,4718,6307,4472,4984,6053,6827,8486,9321,8945,9904,5581,5201,10025,10600,8367,10366,7531,10045,6479,4084,5953,10125,4046,6430,5950,6254,6389,5147,9100,6083,7532,1119,3704,6590,4521,10323,5206,10657,9755,7618,9913,3386,10258,9147,2636,4541,1000,9616,1894,10550,4864,2706,5284,7619,10425,6115,6151,5911,4008,4078,9535,9886,10408,10026,10262,7437,7352,8281,11123,10358,2802,6017,4986,5679,5477,6195,5447,6446,8478,7743,5121,5072,9264,6578,9332,9874,10010,10260,9597,3585,3989,2372,8497,9788,10053,8223,11116,6394,9015,6225,3318,8035,8051,8836,1688,10087,10265,10176,11006,10676,10770,4838,6260,9084,5904,10395,1423,8879,4246,2443,6433,3668,9081,10899,6292,7742,10162,3583,8155,1993,7638,10409,3997,7757,4388,8211,5502,10264,11098,10278,9641,8953,10082,1301,10703,6737,4590,7609,4111,4290,8107,9836,9709,4089,4453,10393,4441,3860,826,7537,10073,9911,5210,7188,4049,10763,7870,8244,2978,7829,7729,10290,6316,6375,10097,7440,8312,9613,6973,10754,4200,395,6485,9508,10670,8705,7467,2574,7193,10135,8342,10050,2452,8471,8147,3287,8364,9869,10994,10261,7246,4178,2185,8863,10116,10678,7170,10390,9612,10268,10546,10591,10562,6903,9493,1680,9933,10263,10897,10672,4168,1036,10534,10051,10797,2058,4317,6272,8339,6286,4349,7970,5875,4372,5861,6047,7244,10392,3883,5602,5303,6248,7190,7048,3864,10269,9916,10564,9941,10207,6570,10391,8707,9887,10575,6561,10679,3165,2251,7671,8496,4975,8933,10142,6900,1887,4081,8882,9428,7236,9089,2608,9334,10193,7859,10952,11036,7382,10801,10839,8906,9570,10444,8631,8031,10549,9895,7075,4183,9930,10651,6558,6139,6838,7946,10471,5661,8623,5315,5334,9118,8493,8823,5854,7076,6391,6597,10424,6407,3366,4406,7327,3458,4728,5260,8968,5853,2512,7507,7198,10308,9594,9903,11082,2552,2428,8156,7945,10322,6898,9725,8935,9271,5415,6454,5060,6403,9049,4883,8122,8978,4641,9584,9764,8659,10490,10637,6746,8308,6675,7950,5079,9995,6783,7128,5311,10196,10631,4491,5779,6261,6708,7954,9724,6383,7805,10127,10685,7662,8037,3147,6521,3855,4222,1219,9361,5394,5431,2459,5920,5609,2649,10077,9690,2583,9799,7408,8797,9698,6243,9556,9591,11117,4663,2564,4706,10204,11014,9243,7784,10491,9282,9966,10862,6756,8448,9548,1452,8615,8760,5828,3281,9509,10798,10574,2504,9603,8491,10577,9668,2427,9994,4836,7295,4442,6618,8632,10689,6858,7698,6213,8700,4348,10327,7311,7556,367,5304,7009,7368,6341,9575,7046,11026,10769,10954,10518,6008,7881,10665,11058,10875,8291,10517,8548,7938,10605,9803,8288,3719,10780,6370,8229,9021,8674,7935,8545,7217,10868,10521,6990,4210,9086,5356,282,6281,7410,8874,4615,5248,8579,10062,10239,6612,9495,9856,8858,11033,7272,10810,11052,5777,10711,8828,10306,11111,11081,10730,10834,11118,2329,6110,10966,8261,2821,9097,7292,6434,7397,4958,4909,10975,8370,6535,4921,5272,9254,10454,2889,7059,9221,8505,7767,10587,9767,9507,11012,9266,7612,9000,7690,8290,4978,6246,7254,9227,8732,8570,1817,6688,10312,10990,8994,2165,7761,8794,8749,10333,1714,5205,2963,2171,1931,9749,9222,5752,6355,2173,5666,9658,8380,10893,5744,7318,5868,1818,2962,5203,8894,9682,10337,8453,7696,1901,7206,4336,10825,9661,5074,5539,4953,4775,721,8345,8855,5412,9345,9974,10179,9660,1564" forcepingid="" preferredserverid="" />
<licensekey>9c1687ea58e5e770-1df5b7cd427370f7-4b62a84526ea1f56</licensekey>
<customer>speedtest</customer>
<odometer start="9445560235" rate="19" />
<times dl1="5000000" dl2="35000000" dl3="800000000" ul1="1000000" ul2="8000000" ul3="35000000" />
<download testlength="10" initialtest="250K" mintestsize="250K" threadsperurl="4" />
<upload testlength="10" ratio="5" initialtest="0" mintestsize="32K" threads="2" maxchunksize="512K" maxchunkcount="50" threadsperurl="4" />
<latency testlength="10" waittime="50" timeout="20" />
<socket-download testlength="15" initialthreads="4" minthreads="4" maxthreads="32" threadratio="750K" maxsamplesize="5000000" minsamplesize="32000" startsamplesize="1000000" startbuffersize="1" bufferlength="5000" packetlength="1000" readbuffer="65536" />
<socket-upload   testlength="15" initialthreads="dyn:tcpulthreads" minthreads="dyn:tcpulthreads" maxthreads="32" threadratio="750K" maxsamplesize="1000000" minsamplesize="32000" startsamplesize="100000" startbuffersize="2" bufferlength="1000" packetlength="1000" disabled="false" />
<socket-latency testlength="10" waittime="50" timeout="20" />
<conditions>
<cond name="tcpulthreads" download="+100000" value="8" />
<cond name="tcpulthreads" download="+10000" value="4" />
<cond name="tcpulthreads" value="2" />
</conditions><interface template="mbps" colortcp="0" />
<translation lang="xml" >
<text id="rateyourisp">Rate Your ISP</text>
<text id="copy">COPY IP</text>
<text id="long-kbps">kilobits</text>
<text id="long-Mbps">megabits</text>
<text id="newserver">NEW SERVER</text>
<text id="testagain">TEST AGAIN</text>
<text id="uploadspeed">UPLOAD SPEED</text>
<text id="downloadspeed">DOWNLOAD SPEED</text>
<text id="kbps">kbps</text>
<text id="Mbps">Mbps</text>
<text id="begintest">BEGIN TEST</text>
<text id="startclosest">START TEST TO RECOMMENDED SERVER</text>
<text id="long-MB/s">megabytes</text>
<text id="long-kB/s">kilobytes</text>
<text id="kB/s">kB/s</text>
<text id="MB/s">MB/s</text>
<text id="mbps">Mbps</text>
<text id="ratinghelp">How happy are you with your current Internet service provider?</text>
<text id="rating1">Very unhappy</text>
<text id="rating2">Unhappy</text>
<text id="rating3">Neutral</text>
<text id="rating4">Happy</text>
<text id="rating5">Very happy</text>
<text id="speedwavebegin">YOUR RESULT WILL BECOME PART OF A SPEED WAVE</text>
<text id="ping">PING</text>
<text id="hostedby">Hosted by</text>
<text id="counterdescription">TOTAL TESTS
TO DATE</text>
<text id="copied">COPIED</text>
<text id="autostartdesc">AUTO STARTING SPEED TEST IN</text>
<text id="seconds">SECONDS</text>
<text id="second">SECOND</text>
<text id="error">ERROR</text>
<text id="tryagain">Try Again</text>
<text id="share-wavetitle">START A SPEED WAVE</text>
<text id="share-namewave">Speed Wave Name</text>
<text id="share-waveresults">Your result is now part of the Speed Wave!</text>
<text id="compare-yourtest">Your Result</text>
<text id="survey-surveytitle">Help Us Understand Broadband Costs</text>
<text id="survey-downloadpackage">Download Package</text>
<text id="survey-uploadpackage">Upload Package</text>
<text id="survey-howmuch">How much do you pay?</text>
<text id="survey-includes">Includes:</text>
<text id="survey-postalcode">Is this your postal code?</text>
<text id="survey-submit">SUBMIT</text>
<text id="share-accounttitle">GET A FREE OOKLA SPEEDTEST ACCOUNT</text>
<text id="share-accountdescription">Being logged in would allow you to start a Speed Wave here!
Registration is free and only requires a valid email address.</text>
<text id="share-emailaddress">Your Email Address</text>
<text id="share-twitterurl">https://twitter.com/share?text=Check%20out%20my%20%40Ookla%20Speedtest%20result!%20What%27s%20your%20speed%3F&amp;url=http%3A%2F%2Fwww.speedtest.net%2Fmy-result%2F{RESULTID}&amp;related=ookla%3ACreators%20of%20Ookla%20Speedtest&amp;hashtags=speedtest</text>
<text id="share-facebookurl">https://www.facebook.com/dialog/feed?app_id=581657151866321&amp;link=http://www.speedtest.net/my-result/{RESULTID}&amp;description=This%20is%20my%20Ookla%20Speedtest%20result.%20Compare%20your%20speed%20to%20mine!&amp;redirect_uri=http://www.speedtest.net&amp;name=Check%20out%20my%20Ookla%20Speedtest%20results.%20What%27s%20your%20speed%3F</text>
<text id="share-viewwave">VIEW SPEED WAVE</text>
<text id="share-createwave">CREATE</text>
<text id="survey-speed">Speed</text>
<text id="survey-phone">Phone</text>
<text id="survey-tv">TV</text>
<text id="survey-package">What speeds do you pay for?</text>
<text id="survey-thanks">Thanks for participating in the survey!</text>
<text id="selectingbestserver">SELECTING BEST SERVER BASED ON PING</text>
<text id="compare-myresults">MY RESULTS</text>
<text id="share-createaccount">CREATE</text>
<text id="begintest-preferred">YOUR PREFERRED SERVER</text>
<text id="begintest-ping">RECOMMENDED SERVER</text>
<text id="connecting">CONNECTING</text>
<text id="share-copy">COPY</text>
<text id="endtest-share-button">SHARE THIS RESULT</text>
<text id="endtest-compare-button">COMPARE 
YOUR RESULT</text>
<text id="endtest-contribute-button">CONTRIBUTE
TO NET INDEX</text>
<text id="close">CLOSE</text>
<text id="survey-retake">RETAKE THE
SURVEY</text>
<text id="share-link">IMAGE</text>
<text id="share-forum">FORUM</text>
<text id="share-wavedescription">Use this test result to begin your own Speed Wave!</text>
<text id="pcmagmessage">Fastest ISPs</text>
<text id="panel0">wave</text>
<text id="panel1">share</text>
<text id="panel2">link:{LANG_CODE}/results.php?source=compare</text>
<text id="panel3">contribute</text>
<text id="bitspersecond">bits per second</text>
<text id="endtest">standard</text>
<text id="lang">en</text>
<text id="share-pinteresturl">http://pinterest.com/pin/create/button/?url=http%3A%2F%2Fwww.speedtest.net%2F&amp;media=http%3A%2F%2Fspeedtest.net%2Fresult%2F{RESULTID}.png&amp;description=Check%20out%20my%20result%20from%20Ookla%20Speedtest!</text>
<text id="panelsuffix"></text>
<text id="survey-nextbtn">Continue</text>
<text id="survey-editbtn">EDIT</text>
<text id="survey-download">Download</text>
<text id="survey-download-validate">Download:</text>
<text id="survey-upload">Upload</text>
<text id="survey-upload-validate">Upload:</text>
<text id="survey-connectiontype">Connection Type?</text>
<text id="survey-q1label1">Home</text>
<text id="survey-q1label2">Business</text>
<text id="survey-q1label3">School</text>
<text id="survey-q1label4">Public Wi-Fi</text>
<text id="survey-q1label5">Other</text>
<text id="survey-ispconf">My ISP is:</text>
<text id="survey-q2label1">Yes</text>
<text id="survey-q2label2">Wrong</text>
<text id="survey-q3label1">Yes</text>
<text id="survey-q3label2">Wrong</text>
<text id="survey-postalcode-input">Please enter your postal code</text>
<text id="survey-labelispinput">Please enter your ISP name</text>
<text id="survey-okbtn">OK</text>
<text id="survey-validationUploadline1">Please check your upload speed.
  This seems faster than expected.</text>
<text id="survey-validationAmountline1">Please check the amount entered.
    This seems higher than expected.</text>
<text id="survey-validationDownloadline1">Please check your Download speed.
  This seems faster than expected.</text>
<text id="share-web">WEB</text>
<text id="share-html">EMBED</text>
<text id="endtest-contribute-are-you-on">Are you on</text>
<text id="endtest-contribute-take-survey">Take our Broadband Internet Survey!</text>
<text id="endtest-test-again">TEST AGAIN</text>
<text id="endtest-compare">COMPARE</text>
</translation>
<survey>
<defaults postal_code="" isp_name="Wavenet Media Service" isp_common_name="Wavenet Media Service"/>
<currency sign="Rp" rate_USD="0.0001"/>
</survey><panels panel0="wave-bd-wide" panel1="share-wide" panel2="link:/results.php?source=compare" panel3="contribute-wide-new:wide"/>
<endtest endtest="standard-wide-new-1button" /><override>
<banner id="60" url="http://speedify.com/spotlight/lp-1-1/?source=ookla&amp;campaign=speedtest01&amp;utm_source=speedtest&amp;utm_medium=banner&amp;utm_campaign=speedtest01" banner="http://c.speedtest.net/flash/60speedify2-en.swf" target="_blank" present="true" />

</override>
</settings>
